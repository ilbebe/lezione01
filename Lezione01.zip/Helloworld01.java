public class Helloworld01 {

  private static final String MESSAGGIO = "Hello, world!!!";

  public static void main(String args[]) {
    System.out.println(MESSAGGIO);
  }

}
