package it.extracube.corsojava.lezione01.helloworld05;

public final class SalutoEnglish extends AbstractBaseSaluto {
  private static final String SALUTO = "Hello, World";

  public SalutoEnglish() {
    super(SALUTO);
  }

}
