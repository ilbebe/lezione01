package it.extracube.corsojava.lezione01.helloworld05;

public final class SalutoFrancaise extends AbstractBaseSaluto {
  private static final String SALUTO = "Salut, Monde";

  public SalutoFrancaise() {
    super(SALUTO);
  }
}
