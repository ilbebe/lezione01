package it.extracube.corsojava.lezione01.helloworld05;

public final class SalutoItaliano  extends AbstractBaseSaluto {
  private static final String SALUTO = "Ciao, Mondo";

  public SalutoItaliano() {
    super(SALUTO);
  }
}
